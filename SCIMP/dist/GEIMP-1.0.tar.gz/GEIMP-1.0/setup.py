from distutils.core import setup

setup(
    name="GEIMP",
    version="1.0",
    description="Method for single cell imputation",
    author="Caterpillar",
    author_email="1510305111@pku.edu.cn",
    py_modules=["GEImpute"]
    )
